package com.magasinspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MagasinSpringApplicationTests {

    @Test
    void contextLoads() {
    }

}
