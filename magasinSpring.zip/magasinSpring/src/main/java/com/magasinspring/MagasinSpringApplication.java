package com.magasinspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;

@SpringBootApplication
@ComponentScan(basePackages = {"com.magasinspring.dao"})
public class MagasinSpringApplication {

    public static void main(String[] args) {
        SpringApplication.run(MagasinSpringApplication.class, args);
    }

}
